package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojo.Jobs;

public interface JobsRepo extends JpaRepository<Jobs, Integer> {
	

}
