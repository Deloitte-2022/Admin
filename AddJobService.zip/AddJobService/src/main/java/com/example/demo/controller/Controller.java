package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.JobsRepo;
import com.example.demo.pojo.Jobs;

@RestController
public class Controller {
	
	@Autowired
	JobsRepo repo;
	
	@PostMapping("/jobs")
	public ResponseEntity<Jobs> addJobs(@RequestBody Jobs jobs){
		return new ResponseEntity<Jobs>(repo.save(jobs),HttpStatus.OK);
	}

}
