package com.example.demo.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Jobs {
	@Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int jobId;
    private int cmpId;
    private String jobType;
    private int salary;
    private  int experience;
	public int getJobId() {
		return jobId;
	}
	public void setJobId(int jobId) {
		this.jobId = jobId;
	}
	public int getCmpId() {
		return cmpId;
	}
	public void setCmpId(int cmpId) {
		this.cmpId = cmpId;
	}
	public String getJobType() {
		return jobType;
	}
	public void setJobType(String jobType) {
		this.jobType = jobType;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	public int getExperience() {
		return experience;
	}
	public void setExperience(int experience) {
		this.experience = experience;
	}
	@Override
	public String toString() {
		return "Jobs [jobId=" + jobId + ", cmpId=" + cmpId + ", jobType=" + jobType + ", salary=" + salary
				+ ", experience=" + experience + "]";
	}
	public Jobs() {
		super();
	}
    
    
	
	

}
