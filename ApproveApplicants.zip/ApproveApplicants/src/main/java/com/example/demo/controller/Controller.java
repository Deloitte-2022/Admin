package com.example.demo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.ApplicantRepo;
import com.example.demo.pojo.Applicant;

@RestController
public class Controller {
	@Autowired
	ApplicantRepo repo;
	
	@GetMapping("/applicants")
	public ResponseEntity<List<Applicant>> findAllApplicants(){
		return new ResponseEntity<List<Applicant>>(repo.findAll(),HttpStatus.OK);
		
		
	}
	
	

}
