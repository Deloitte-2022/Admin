package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.pojo.Applicant;

public interface ApplicantRepo extends JpaRepository<Applicant, Integer> {
	

}
