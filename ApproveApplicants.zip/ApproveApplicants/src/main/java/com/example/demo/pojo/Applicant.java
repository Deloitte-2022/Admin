package com.example.demo.pojo;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Applicant {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String name;
	private String dob;
	private int phone_number;
	private String email;
	private String education;
	private String stream;
	private int year_of_passing;
	private String address;
	private String gender;
	private int expirence;
	public Applicant() {
		super();
	}
	@Override
	public String toString() {
		return "Applicant [id=" + id + ", name=" + name + ", dob=" + dob + ", phone_number=" + phone_number + ", email="
				+ email + ", education=" + education + ", stream=" + stream + ", year_of_passing=" + year_of_passing
				+ ", address=" + address + ", gender=" + gender + ", expirence=" + expirence + "]";
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDob() {
		return dob;
	}
	public void setDob(String dob) {
		this.dob = dob;
	}
	public int getPhone_number() {
		return phone_number;
	}
	public void setPhone_number(int phone_number) {
		this.phone_number = phone_number;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getStream() {
		return stream;
	}
	public void setStream(String stream) {
		this.stream = stream;
	}
	public int getYear_of_passing() {
		return year_of_passing;
	}
	public void setYear_of_passing(int year_of_passing) {
		this.year_of_passing = year_of_passing;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getExpirence() {
		return expirence;
	}
	public void setExpirence(int expirence) {
		this.expirence = expirence;
	}
	
	
	

}
