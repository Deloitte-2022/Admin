package com.example.demo.pojo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.dao.CompanyRepo;
import com.example.demo.pojo.Company;




@RestController
public class Controller {
	
	@Autowired
	CompanyRepo repo;
	
	
	
	  @PostMapping("/company-jpa") public Company createNewProject(@RequestBody
	  Company company) { return repo.save(company); }
	 
	/*
	 * @PostMapping("/company-save") public ResponseEntity<Company>
	 * addEmployee(@RequestBody Company company){ return new
	 * ResponseEntity<Company>(repo.save(company),HttpStatus.OK); }
	 */

}
