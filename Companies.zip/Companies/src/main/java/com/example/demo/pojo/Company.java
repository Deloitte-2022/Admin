package com.example.demo.pojo;

import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Transient;

@Entity
public class Company {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cmpId;
	private String cmpName;
	private String cmpHqtr;
	private String type;
	@Transient
	private List<Job> jobs;

	public Company() {
		super();
	}

	@Override
	public String toString() {
		return "Company [cmpId=" + cmpId + ", cmpName=" + cmpName + ", cmpHqtr=" + cmpHqtr + ", type=" + type
				+ ", jobs=" + jobs + "]";
	}

	public int getCmpId() {
		return cmpId;
	}

	public void setCmpId(int cmpId) {
		this.cmpId = cmpId;
	}

	public String getCmpName() {
		return cmpName;
	}

	public void setCmpName(String cmpName) {
		this.cmpName = cmpName;
	}

	public String getCmpHqtr() {
		return cmpHqtr;
	}

	public void setCmpHqtr(String cmpHqtr) {
		this.cmpHqtr = cmpHqtr;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public List<Job> getJobs() {
		return jobs;
	}

	public void setJobs(List<Job> jobs) {
		this.jobs = jobs;
	}

}
