package com.example.demo.dao;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.pojo.Company;


public interface CompanyRepo extends JpaRepository<Company, Integer> {
	


}
